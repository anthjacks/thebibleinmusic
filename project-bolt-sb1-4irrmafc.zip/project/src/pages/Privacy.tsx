import { Shield, Lock, Eye, Database, Mail, ArrowLeft, Music2 } from 'lucide-react';
import { useNavigate } from '../hooks/useNavigate';

export function Privacy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => navigate('landing')}
              className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                <Music2 className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-gray-900">The Bible In Music</span>
            </div>
          </div>
        </div>
      </header>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-2xl mb-4">
            <Shield className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Privacy Policy</h1>
          <p className="text-gray-600">Last Updated: February 2024</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 space-y-8">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex gap-3">
            <Lock className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-green-900">
              Your privacy is important to us. This policy explains how we collect, use, and protect your personal information.
            </p>
          </div>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Information We Collect</h2>

            <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-600" />
              Information You Provide
            </h3>
            <p className="text-gray-700 mb-3">When you create an account, we collect:</p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700 mb-6">
              <li><strong>Email address:</strong> Used for account authentication and communication</li>
              <li><strong>Username:</strong> Your chosen display name</li>
              <li><strong>Password:</strong> Securely encrypted and never stored in plain text</li>
              <li><strong>Language preference:</strong> English or Spanish</li>
              <li><strong>Premium status:</strong> Whether you have purchased premium access</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Eye className="w-5 h-5 text-purple-600" />
              Automatically Collected Information
            </h3>
            <p className="text-gray-700 mb-3">When you use our service, we automatically collect:</p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li><strong>Usage data:</strong> What Bible chapters and music you listen to</li>
              <li><strong>Listening sessions:</strong> Duration and frequency of listening</li>
              <li><strong>Device information:</strong> Browser type, operating system, device type</li>
              <li><strong>IP address:</strong> For security and analytics purposes</li>
              <li><strong>Favorites and playlists:</strong> Content you save or organize</li>
              <li><strong>Download history:</strong> Tracks you download (premium users only)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">2. How We Use Your Information</h2>
            <p className="text-gray-700 mb-3">We use the information we collect to:</p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li>Provide and maintain the Service</li>
              <li>Authenticate your account and manage sessions</li>
              <li>Personalize your experience (language, continue listening, etc.)</li>
              <li>Process premium subscriptions and payments</li>
              <li>Track ad timing for free users (3 ads per hour)</li>
              <li>Improve content recommendations</li>
              <li>Analyze usage patterns to enhance the Service</li>
              <li>Send important service announcements and updates</li>
              <li>Prevent fraud and ensure security</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Information Sharing and Disclosure</h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              <strong>We do not sell your personal information to third parties.</strong>
            </p>
            <p className="text-gray-700 mb-3">We may share your information only in these limited circumstances:</p>

            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Service Providers</h3>
                <p className="text-gray-700">
                  We use trusted third-party services to operate our platform:
                </p>
                <ul className="list-disc list-inside space-y-1 ml-4 text-gray-700 mt-2">
                  <li><strong>Supabase:</strong> Database and authentication</li>
                  <li><strong>Stripe:</strong> Payment processing (they handle your payment info securely)</li>
                  <li><strong>Hosting provider:</strong> To serve the application</li>
                  <li><strong>CDN:</strong> To deliver audio content efficiently</li>
                </ul>
                <p className="text-gray-700 mt-2">
                  These providers are contractually obligated to protect your data and use it only for providing services to us.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Legal Requirements</h3>
                <p className="text-gray-700">
                  We may disclose your information if required by law, court order, or government request, or to protect our rights, property, or safety.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-1">Business Transfers</h3>
                <p className="text-gray-700">
                  If we are involved in a merger, acquisition, or sale of assets, your information may be transferred as part of that transaction.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Data Security</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              We implement industry-standard security measures to protect your information:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li><strong>Encryption:</strong> All data transmitted between your device and our servers is encrypted using HTTPS/TLS</li>
              <li><strong>Password security:</strong> Passwords are hashed using bcrypt and never stored in plain text</li>
              <li><strong>Database security:</strong> Row-level security policies ensure users can only access their own data</li>
              <li><strong>Secure authentication:</strong> Supabase handles authentication with industry best practices</li>
              <li><strong>Regular updates:</strong> We keep our systems updated with the latest security patches</li>
            </ul>
            <p className="text-gray-700 mt-4">
              However, no method of transmission over the internet is 100% secure. While we strive to protect your data, we cannot guarantee absolute security.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Data Retention</h2>
            <p className="text-gray-700 leading-relaxed">
              We retain your personal information for as long as your account is active or as needed to provide you services. If you delete your account, we will delete your personal information within 30 days, except where we are required to retain it for legal or business purposes (e.g., payment records for tax compliance).
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Your Rights and Choices</h2>
            <p className="text-gray-700 mb-3">You have the following rights regarding your personal information:</p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li><strong>Access:</strong> Request a copy of the personal information we hold about you</li>
              <li><strong>Correction:</strong> Update or correct inaccurate information in your profile settings</li>
              <li><strong>Deletion:</strong> Request deletion of your account and personal data</li>
              <li><strong>Data portability:</strong> Request your data in a machine-readable format</li>
              <li><strong>Opt-out:</strong> Unsubscribe from marketing emails (we send very few)</li>
              <li><strong>Object:</strong> Object to certain processing activities</li>
            </ul>
            <p className="text-gray-700 mt-4">
              To exercise these rights, please contact us at privacy@excellentmusic.com.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Cookies and Tracking</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              We use minimal cookies and local storage to:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li>Keep you logged in (authentication token)</li>
              <li>Remember your language preference</li>
              <li>Store your listening position for "Continue Listening"</li>
              <li>Enable PWA functionality and offline access</li>
            </ul>
            <p className="text-gray-700 mt-4">
              We do not use third-party advertising cookies or tracking pixels. We do not track you across other websites.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Children's Privacy</h2>
            <p className="text-gray-700 leading-relaxed">
              Our Service is intended for users aged 13 and older. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us and we will delete it immediately.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">9. International Users</h2>
            <p className="text-gray-700 leading-relaxed">
              Our Service is hosted in the United States. If you are accessing the Service from outside the United States, your information will be transferred to, stored, and processed in the United States. By using the Service, you consent to this transfer.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">10. California Privacy Rights</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              If you are a California resident, you have additional rights under the California Consumer Privacy Act (CCPA):
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li>Right to know what personal information we collect and how we use it</li>
              <li>Right to delete your personal information</li>
              <li>Right to opt-out of the sale of personal information (we don't sell your data)</li>
              <li>Right to non-discrimination for exercising your privacy rights</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">11. European Privacy Rights (GDPR)</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              If you are in the European Economic Area (EEA), you have rights under the General Data Protection Regulation (GDPR):
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li>Right of access to your personal data</li>
              <li>Right to rectification of inaccurate data</li>
              <li>Right to erasure ("right to be forgotten")</li>
              <li>Right to restrict processing</li>
              <li>Right to data portability</li>
              <li>Right to object to processing</li>
              <li>Rights related to automated decision-making</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Changes to This Privacy Policy</h2>
            <p className="text-gray-700 leading-relaxed">
              We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. We will notify you of significant changes by posting the updated policy on this page and updating the "Last Updated" date. We encourage you to review this policy periodically.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Mail className="w-6 h-6 text-blue-600" />
              13. Contact Us
            </h2>
            <p className="text-gray-700 leading-relaxed mb-4">
              If you have questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us:
            </p>
            <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-gray-700">
              <p><strong>Email:</strong> privacy@excellentmusic.com</p>
              <p><strong>Support:</strong> support@excellentmusic.com</p>
              <p><strong>Website:</strong> www.thebibleinmusic.org</p>
            </div>
          </section>

          <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-xl p-6 text-white">
            <h3 className="font-bold text-lg mb-2">Our Commitment to You</h3>
            <p className="text-green-100">
              We are committed to transparency, security, and respecting your privacy. Your trust is essential to our ministry, and we will never compromise it. Thank you for choosing The Bible In Music.
            </p>
          </div>
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Copyright © 2024 Excellent Music. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
