import { Music2, Heart, Globe, Users, Award, Book, ArrowLeft } from 'lucide-react';
import { useNavigate } from '../hooks/useNavigate';

export function About() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-orange-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => navigate('landing')}
              className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                <Music2 className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-gray-900">The Bible In Music</span>
            </div>
          </div>
        </div>
      </header>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl mb-6">
            <Music2 className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About The Bible In Music</h1>
          <p className="text-xl text-gray-600">Making God's Word accessible through audio</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            The Bible In Music exists to make God's Word accessible to everyone through audio, combined with uplifting Christian worship music. We believe in the power of scripture and song to transform lives, and we're committed to providing this content to as many people as possible, regardless of their ability to pay.
          </p>
          <p className="text-gray-700 leading-relaxed">
            Our freemium model ensures that everyone can access the complete Bible and worship music library for free, while premium features support our ministry and help us continue spreading the Gospel.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Book className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Complete Bible</h3>
            </div>
            <p className="text-gray-700">
              Access all 66 books and 1,189 chapters of the Bible in English and Spanish audio format.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Music2 className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Christian Music</h3>
            </div>
            <p className="text-gray-700">
              Enjoy a curated library of Christian worship music, hymns, and contemporary praise songs.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Ministry First</h3>
            </div>
            <p className="text-gray-700">
              10% of all premium subscriptions go directly to supporting local churches and ministries.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Globe className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Global Access</h3>
            </div>
            <p className="text-gray-700">
              Available worldwide as a Progressive Web App that works on any device, online or offline.
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl shadow-lg p-8 mb-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Users className="w-8 h-8" />
            <h2 className="text-2xl font-bold">By Excellent Music</h2>
          </div>
          <p className="text-blue-100 leading-relaxed mb-4">
            The Bible In Music is a ministry of Excellent Music, dedicated to producing and distributing Christ-centered audio content that inspires faith, encourages believers, and introduces seekers to the life-changing message of the Gospel.
          </p>
          <p className="text-blue-100 leading-relaxed">
            Founded with a passion for worship and a heart for missions, we combine professional audio production with ministry excellence to create resources that serve the global church.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <Award className="w-8 h-8 text-amber-600" />
            <h2 className="text-2xl font-bold text-gray-900">Our Values</h2>
          </div>
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Scripture First</h3>
              <p className="text-gray-700">God's Word is our foundation and our primary content.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Accessibility</h3>
              <p className="text-gray-700">Everyone deserves access to scripture and worship music.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Excellence</h3>
              <p className="text-gray-700">We strive for professional quality in everything we produce.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Generosity</h3>
              <p className="text-gray-700">We give back to churches and ministries from our revenue.</p>
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-1">Innovation</h3>
              <p className="text-gray-700">We use modern technology to reach people where they are.</p>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl shadow-lg p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">Join Our Mission</h2>
          <p className="text-orange-100 mb-6">
            By upgrading to premium for just $9.99, you not only get lifetime access to ad-free listening, downloads, and playlists—you also help us expand our content library and support churches worldwide.
          </p>
          <p className="text-orange-100 font-semibold">
            Thank you for being part of this ministry!
          </p>
        </div>

        <div className="text-center mt-8">
          <p className="text-gray-600">
            Questions or feedback?{' '}
            <a href="mailto:support@excellentmusic.com" className="text-blue-600 hover:underline font-medium">
              Contact us
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
