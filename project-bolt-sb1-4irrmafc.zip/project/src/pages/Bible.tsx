import { useState, useEffect } from 'react';
import { Book, Play, Globe, Pause, Volume2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { usePlayer } from '../contexts/PlayerContext';
import { useAuth } from '../contexts/AuthContext';

interface BibleAudio {
  id: string;
  book: string;
  chapter: number;
  title: string;
  file_url: string;
  thumbnail_url?: string;
  language?: string;
  artist?: string;
  duration?: number;
}

const BIBLICAL_ORDER = [
  'Genesis', 'Exodus', 'Leviticus', 'Numbers', 'Deuteronomy',
  'Joshua', 'Judges', 'Ruth', '1 Samuel', '2 Samuel', '1 Kings', '2 Kings',
  '1 Chronicles', '2 Chronicles', 'Ezra', 'Nehemiah', 'Esther',
  'Job', 'Psalms', 'Proverbs', 'Ecclesiastes', 'Song of Solomon',
  'Isaiah', 'Jeremiah', 'Lamentations', 'Ezekiel', 'Daniel',
  'Hosea', 'Joel', 'Amos', 'Obadiah', 'Jonah', 'Micah', 'Nahum',
  'Habakkuk', 'Zephaniah', 'Haggai', 'Zechariah', 'Malachi',
  'Matthew', 'Mark', 'Luke', 'John', 'Acts',
  'Romans', '1 Corinthians', '2 Corinthians', 'Galatians', 'Ephesians',
  'Philippians', 'Colossians', '1 Thessalonians', '2 Thessalonians',
  '1 Timothy', '2 Timothy', 'Titus', 'Philemon',
  'Hebrews', 'James', '1 Peter', '2 Peter', '1 John', '2 John', '3 John',
  'Jude', 'Revelation',
  'Génesis', 'Éxodo', 'Levítico', 'Números', 'Deuteronomio',
  'Josué', 'Jueces', 'Rut', '1 Samuel', '2 Samuel', '1 Reyes', '2 Reyes',
  '1 Crónicas', '2 Crónicas', 'Esdras', 'Nehemías', 'Ester',
  'Job', 'Salmos', 'Proverbios', 'Eclesiastés', 'Cantares',
  'Isaías', 'Jeremías', 'Lamentaciones', 'Ezequiel', 'Daniel',
  'Oseas', 'Joel', 'Amós', 'Abdías', 'Jonás', 'Miqueas', 'Nahúm',
  'Habacuc', 'Sofonías', 'Hageo', 'Zacarías', 'Malaquías',
  'Mateo', 'Marcos', 'Lucas', 'Juan', 'Hechos',
  'Romanos', '1 Corintios', '2 Corintios', 'Gálatas', 'Efesios',
  'Filipenses', 'Colosenses', '1 Tesalonicenses', '2 Tesalonicenses',
  '1 Timoteo', '2 Timoteo', 'Tito', 'Filemón',
  'Hebreos', 'Santiago', '1 Pedro', '2 Pedro', '1 Juan', '2 Juan', '3 Juan',
  'Judas', 'Apocalipsis'
];

export function Bible() {
  const [availableBooks, setAvailableBooks] = useState<string[]>([]);
  const [selectedBook, setSelectedBook] = useState<string>('');
  const [chapters, setChapters] = useState<BibleAudio[]>([]);
  const [language, setLanguage] = useState<'english' | 'spanish'>('english');
  const [loading, setLoading] = useState(false);
  const { playTrack, currentTrack, isPlaying, togglePlayPause, currentTime, duration } = usePlayer();
  const { profile } = useAuth();

  useEffect(() => {
    if (profile?.preferred_language) {
      setLanguage(profile.preferred_language as 'english' | 'spanish');
    }
  }, [profile]);

  useEffect(() => {
    loadAvailableBooks();
  }, [language]);

  useEffect(() => {
    if (selectedBook) {
      loadChapters();
    } else {
      setChapters([]);
    }
  }, [selectedBook, language]);

  const loadAvailableBooks = async () => {
    const { data, error } = await supabase
      .from('bible_audio')
      .select('book, language')
      .order('book');

    if (error) {
      console.error('Error loading books:', error);
      return;
    }

    if (data) {
      const filteredBooks = data
        .filter(item => {
          const itemLang = item.language?.toLowerCase() || 'english';
          return itemLang === language;
        })
        .map(item => item.book);

      const uniqueBooks = Array.from(new Set(filteredBooks));

      const sortedBooks = uniqueBooks.sort((a, b) => {
        const indexA = BIBLICAL_ORDER.indexOf(a);
        const indexB = BIBLICAL_ORDER.indexOf(b);

        if (indexA === -1 && indexB === -1) return a.localeCompare(b);
        if (indexA === -1) return 1;
        if (indexB === -1) return -1;
        return indexA - indexB;
      });

      setAvailableBooks(sortedBooks);
    }
  };

  const loadChapters = async () => {
    if (!selectedBook) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('bible_audio')
      .select('*')
      .eq('book', selectedBook)
      .order('chapter');

    if (error) {
      console.error('Error loading chapters:', error);
    } else {
      setChapters(data as BibleAudio[]);
    }
    setLoading(false);
  };

  const formatTitle = (title: string): string => {
    return title.replace(/\.wav$/i, '').replace(/\.mp3$/i, '');
  };

  const formatTime = (seconds: number): string => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePlayChapter = (chapter: BibleAudio) => {
    playTrack({
      id: chapter.id,
      title: formatTitle(chapter.title),
      content_type: 'bible',
      language: (chapter.language?.toLowerCase() as 'english' | 'spanish') || language,
      artist: chapter.artist || null,
      album: null,
      book_name: chapter.book,
      chapter_number: chapter.chapter,
      duration_seconds: chapter.duration || 0,
      audio_url: chapter.file_url,
      cover_image_url: chapter.thumbnail_url || null,
      quality_standard: chapter.file_url,
      quality_premium: null,
    });
  };

  const isCurrentlyPlaying = (chapterId: string) => {
    return currentTrack?.id === chapterId && isPlaying;
  };

  const handleChapterClick = (chapter: BibleAudio) => {
    if (currentTrack?.id === chapter.id) {
      togglePlayPause();
    } else {
      handlePlayChapter(chapter);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-blue-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-600 to-orange-700 rounded-2xl flex items-center justify-center shadow-lg">
              <Book className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900">Bible Audio</h1>
              <p className="text-gray-600">Listen to the Word of God</p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-white border-2 border-gray-200 rounded-xl p-1 shadow-md">
            <button
              onClick={() => {
                setLanguage('english');
                setSelectedBook('');
              }}
              className={`px-4 py-2.5 rounded-lg font-medium transition-all ${
                language === 'english'
                  ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                English
              </div>
            </button>
            <button
              onClick={() => {
                setLanguage('spanish');
                setSelectedBook('');
              }}
              className={`px-4 py-2.5 rounded-lg font-medium transition-all ${
                language === 'spanish'
                  ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                Español
              </div>
            </button>
          </div>
        </div>

        {/* Book Selector */}
        <div className="bg-white rounded-2xl shadow-xl border-2 border-amber-100 p-6 md:p-8 mb-8">
          <div className="mb-6">
            <label className="block text-lg font-bold text-gray-900 mb-3">
              Select a Bible Book
            </label>
            <div className="relative">
              <select
                value={selectedBook}
                onChange={(e) => setSelectedBook(e.target.value)}
                className="w-full px-5 py-4 pr-12 bg-gradient-to-r from-gray-50 to-white border-2 border-gray-300 rounded-xl shadow-sm focus:border-blue-500 focus:ring-4 focus:ring-blue-200 transition-all appearance-none text-gray-900 font-semibold text-lg cursor-pointer hover:border-gray-400"
              >
                <option value="">-- Choose a Book --</option>
                {availableBooks.map((book) => (
                  <option key={book} value={book}>
                    {book}
                  </option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                <svg className="w-6 h-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>

          {/* Chapters Display */}
          {selectedBook && (
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                <div className="w-1 h-8 bg-gradient-to-b from-amber-500 to-orange-600 rounded-full"></div>
                {selectedBook}
                <span className="text-sm font-normal text-gray-500">
                  ({chapters.length} {chapters.length === 1 ? 'chapter' : 'chapters'})
                </span>
              </h2>

              {loading ? (
                <div className="text-center py-16">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-amber-200 border-t-amber-600 mx-auto mb-4"></div>
                  <p className="text-gray-600 font-medium">Loading chapters...</p>
                </div>
              ) : chapters.length === 0 ? (
                <div className="text-center py-16 bg-gradient-to-br from-gray-50 to-white rounded-xl border-2 border-dashed border-gray-300">
                  <Book className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 font-medium mb-2">No chapters available</p>
                  <p className="text-sm text-gray-500">Content for this book is being added</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                  {chapters.map((chapter) => {
                    const isPlaying = isCurrentlyPlaying(chapter.id);
                    const chapterNum = chapter.chapter;

                    return (
                      <button
                        key={chapter.id}
                        onClick={() => handleChapterClick(chapter)}
                        className={`relative group rounded-xl overflow-hidden transition-all duration-200 ${
                          isPlaying
                            ? 'shadow-2xl scale-105 ring-4 ring-blue-400'
                            : 'shadow-md hover:shadow-xl border-2 border-gray-200 hover:border-amber-400'
                        }`}
                      >
                        <div className="flex flex-col">
                          {chapter.thumbnail_url ? (
                            <div className="relative aspect-square bg-gray-200">
                              <img
                                src={chapter.thumbnail_url}
                                alt={`${selectedBook} Chapter ${chapterNum}`}
                                className="w-full h-full object-cover"
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                  e.currentTarget.nextElementSibling?.classList.remove('hidden');
                                }}
                              />
                              <div className="hidden absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                                <Book className="w-12 h-12 text-white opacity-50" />
                              </div>
                              <div className={`absolute inset-0 flex items-center justify-center ${isPlaying ? 'bg-blue-600/90' : 'bg-black/0 group-hover:bg-black/30'} transition-all`}>
                                <div
                                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                                    isPlaying
                                      ? 'bg-white shadow-lg'
                                      : 'bg-white/90 group-hover:bg-white shadow-md'
                                  }`}
                                >
                                  {isPlaying ? (
                                    <Pause className="w-7 h-7 text-blue-600" />
                                  ) : (
                                    <Play className="w-7 h-7 text-amber-600 ml-0.5" />
                                  )}
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className={`relative aspect-square flex items-center justify-center ${
                              isPlaying
                                ? 'bg-gradient-to-br from-blue-600 to-blue-700'
                                : 'bg-gradient-to-br from-amber-500 to-orange-600 group-hover:from-amber-600 group-hover:to-orange-700'
                            }`}>
                              <Book className="w-12 h-12 text-white opacity-50 absolute" />
                              <div
                                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                                  isPlaying
                                    ? 'bg-white shadow-lg'
                                    : 'bg-white/90 group-hover:bg-white shadow-md'
                                }`}
                              >
                                {isPlaying ? (
                                  <Pause className="w-7 h-7 text-blue-600" />
                                ) : (
                                  <Play className="w-7 h-7 text-amber-600 ml-0.5" />
                                )}
                              </div>
                            </div>
                          )}

                          <div className={`p-3 ${isPlaying ? 'bg-blue-600' : 'bg-white'}`}>
                            <div
                              className={`font-bold text-base mb-1 ${
                                isPlaying ? 'text-white' : 'text-gray-900'
                              }`}
                            >
                              Chapter {chapterNum}
                            </div>
                            <div
                              className={`text-xs font-medium truncate ${
                                isPlaying ? 'text-blue-100' : 'text-gray-600'
                              }`}
                              title={formatTitle(chapter.title)}
                            >
                              {formatTitle(chapter.title)}
                            </div>
                            {chapter.duration && (
                              <div
                                className={`text-xs mt-1 font-medium ${
                                  isPlaying ? 'text-blue-200' : 'text-gray-500'
                                }`}
                              >
                                {formatTime(chapter.duration)}
                              </div>
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {!selectedBook && (
            <div className="text-center py-16">
              <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-amber-100 to-orange-100 rounded-2xl flex items-center justify-center">
                <Book className="w-10 h-10 text-amber-700" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Select a Book to Begin
              </h3>
              <p className="text-gray-600 max-w-md mx-auto">
                Choose a book from the dropdown menu above to see all available chapters
              </p>
            </div>
          )}
        </div>

        {/* Current Player Display */}
        {currentTrack && currentTrack.content_type === 'bible' && (
          <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-2xl border-2 border-blue-400 p-6 text-white">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="w-20 h-20 bg-white bg-opacity-20 rounded-xl flex items-center justify-center flex-shrink-0">
                <Volume2 className="w-10 h-10 text-white" />
              </div>

              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl font-bold mb-1">Now Playing</h3>
                <p className="text-xl text-blue-100 mb-2">
                  {currentTrack.book_name} - Chapter {currentTrack.chapter_number}
                </p>
                <p className="text-sm text-blue-200">
                  {currentTrack.title}
                </p>
              </div>

              <button
                onClick={togglePlayPause}
                className="w-16 h-16 bg-white rounded-full flex items-center justify-center hover:bg-opacity-90 transition shadow-lg flex-shrink-0"
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8 text-blue-600" />
                ) : (
                  <Play className="w-8 h-8 text-blue-600 ml-1" />
                )}
              </button>
            </div>

            {/* Progress Bar */}
            <div className="mt-6">
              <div className="w-full bg-white bg-opacity-20 rounded-full h-2 mb-2">
                <div
                  className="bg-white h-2 rounded-full transition-all duration-300"
                  style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-sm text-blue-100">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
