import { Briefcase, Music2, Code, Headphones, Heart, TrendingUp, ArrowLeft } from 'lucide-react';
import { useNavigate } from '../hooks/useNavigate';

export function Jobs() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 via-white to-blue-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => navigate('landing')}
              className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <Music2 className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-gray-900">The Bible In Music</span>
            </div>
          </div>
        </div>
      </header>
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl mb-6">
            <Briefcase className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Join Our Ministry</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Help us spread God's Word through audio and music. We're looking for talented, passionate people to join our team.
          </p>
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl shadow-lg p-8 mb-12 text-white">
          <h2 className="text-2xl font-bold mb-4">Why Work With Excellent Music?</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex gap-3">
              <Heart className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold mb-1">Ministry-Focused</h3>
                <p className="text-blue-100">Your work directly impacts lives and spreads the Gospel</p>
              </div>
            </div>
            <div className="flex gap-3">
              <TrendingUp className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold mb-1">Growing Platform</h3>
                <p className="text-blue-100">Be part of a rapidly expanding Christian media ministry</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Music2 className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold mb-1">Creative Freedom</h3>
                <p className="text-blue-100">Contribute your ideas and shape our content direction</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Headphones className="w-6 h-6 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold mb-1">Remote-Friendly</h3>
                <p className="text-blue-100">Work from anywhere with flexible schedules</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6 mb-12">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">Open Positions</h2>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Headphones className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-1">Audio Content Producer</h3>
                <p className="text-gray-600 mb-4">Full-time • Remote</p>

                <p className="text-gray-700 mb-4">
                  We're seeking an experienced audio producer to help us create high-quality Bible recordings and curate our music library.
                </p>

                <h4 className="font-bold text-gray-900 mb-2">Responsibilities:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>Produce professional Bible chapter recordings in English and Spanish</li>
                  <li>Edit and master audio files to broadcast quality</li>
                  <li>Source and curate Christian worship music</li>
                  <li>Manage voice talent and recording sessions</li>
                  <li>Ensure consistent audio quality across all content</li>
                </ul>

                <h4 className="font-bold text-gray-900 mb-2">Requirements:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>3+ years of audio production experience</li>
                  <li>Proficiency in audio editing software (Audacity, Adobe Audition, or Pro Tools)</li>
                  <li>Strong understanding of audio quality standards</li>
                  <li>Passion for scripture and Christian ministry</li>
                  <li>Bilingual (English/Spanish) preferred</li>
                </ul>

                <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition">
                  Apply for This Position
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Code className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-1">Full-Stack Developer</h3>
                <p className="text-gray-600 mb-4">Full-time • Remote</p>

                <p className="text-gray-700 mb-4">
                  Join our development team to enhance and expand The Bible In Music platform.
                </p>

                <h4 className="font-bold text-gray-900 mb-2">Responsibilities:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>Develop new features for web and mobile platforms</li>
                  <li>Optimize audio streaming and offline functionality</li>
                  <li>Integrate payment systems and analytics</li>
                  <li>Maintain and improve existing codebase</li>
                  <li>Collaborate with design and content teams</li>
                </ul>

                <h4 className="font-bold text-gray-900 mb-2">Requirements:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>3+ years of web development experience</li>
                  <li>Strong proficiency in React, TypeScript, and modern JavaScript</li>
                  <li>Experience with Supabase, PostgreSQL, or similar databases</li>
                  <li>Understanding of PWA development and service workers</li>
                  <li>Passion for creating user-friendly, ministry-focused applications</li>
                </ul>

                <button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold px-6 py-3 rounded-lg transition">
                  Apply for This Position
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Music2 className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-1">Content Curator</h3>
                <p className="text-gray-600 mb-4">Part-time • Remote</p>

                <p className="text-gray-700 mb-4">
                  Help us discover and organize the best Christian worship music for our growing community.
                </p>

                <h4 className="font-bold text-gray-900 mb-2">Responsibilities:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>Research and identify high-quality Christian music</li>
                  <li>Organize content by genre, mood, and theme</li>
                  <li>Create playlists and collections</li>
                  <li>Write descriptions and metadata for tracks</li>
                  <li>Stay current with Christian music trends</li>
                </ul>

                <h4 className="font-bold text-gray-900 mb-2">Requirements:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>Deep knowledge of Christian worship music</li>
                  <li>Strong organizational skills</li>
                  <li>Excellent written communication</li>
                  <li>Understanding of music licensing and copyright</li>
                  <li>Heart for ministry and worship</li>
                </ul>

                <button className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg transition">
                  Apply for This Position
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Heart className="w-6 h-6 text-amber-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-gray-900 mb-1">Community Manager</h3>
                <p className="text-gray-600 mb-4">Part-time • Remote</p>

                <p className="text-gray-700 mb-4">
                  Build and engage our community of listeners through social media, email, and support channels.
                </p>

                <h4 className="font-bold text-gray-900 mb-2">Responsibilities:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>Manage social media presence (Facebook, Instagram, Twitter)</li>
                  <li>Respond to user questions and feedback</li>
                  <li>Create engaging content and announcements</li>
                  <li>Monitor user satisfaction and gather feedback</li>
                  <li>Build relationships with churches and ministries</li>
                </ul>

                <h4 className="font-bold text-gray-900 mb-2">Requirements:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-2">
                  <li>2+ years of social media or community management experience</li>
                  <li>Excellent communication and interpersonal skills</li>
                  <li>Experience with Christian ministry or nonprofit organizations</li>
                  <li>Creative content creation abilities</li>
                  <li>Passion for serving and encouraging others</li>
                </ul>

                <button className="bg-amber-600 hover:bg-amber-700 text-white font-semibold px-6 py-3 rounded-lg transition">
                  Apply for This Position
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl shadow-lg p-8 text-white text-center mb-8">
          <h2 className="text-2xl font-bold mb-4">Don't See Your Role?</h2>
          <p className="text-orange-100 mb-6 max-w-2xl mx-auto">
            We're always looking for talented people who are passionate about ministry and technology. If you think you'd be a great fit for our team, we'd love to hear from you!
          </p>
          <button className="bg-white text-orange-600 hover:bg-orange-50 font-semibold px-8 py-3 rounded-lg transition">
            Send Us Your Resume
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 text-center">Our Hiring Process</h2>
          <div className="grid md:grid-cols-4 gap-6 mt-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-blue-600 font-bold text-xl">1</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-1">Apply</h3>
              <p className="text-sm text-gray-600">Submit your application and resume</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-green-600 font-bold text-xl">2</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-1">Review</h3>
              <p className="text-sm text-gray-600">We review your qualifications</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-purple-600 font-bold text-xl">3</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-1">Interview</h3>
              <p className="text-sm text-gray-600">Video call with our team</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-amber-600 font-bold text-xl">4</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-1">Welcome!</h3>
              <p className="text-sm text-gray-600">Join our ministry team</p>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-2">
            Questions about working with us?
          </p>
          <a href="mailto:jobs@excellentmusic.com" className="text-blue-600 hover:underline font-medium text-lg">
            jobs@excellentmusic.com
          </a>
        </div>
      </div>
    </div>
  );
}
