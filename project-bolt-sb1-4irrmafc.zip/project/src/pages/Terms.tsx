import { FileText, AlertCircle, ArrowLeft, Music2 } from 'lucide-react';
import { useNavigate } from '../hooks/useNavigate';

export function Terms() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <button
              onClick={() => navigate('landing')}
              className="flex items-center gap-2 text-gray-700 hover:text-gray-900 transition"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                <Music2 className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-gray-900">The Bible In Music</span>
            </div>
          </div>
        </div>
      </header>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-2xl mb-4">
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Terms of Service</h1>
          <p className="text-gray-600">Last Updated: February 2024</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 space-y-8">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-blue-900">
              By accessing or using The Bible In Music, you agree to be bound by these Terms of Service. Please read them carefully.
            </p>
          </div>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Acceptance of Terms</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              By creating an account and using The Bible In Music ("Service"), you agree to these Terms of Service ("Terms"). If you do not agree to these Terms, you may not use the Service.
            </p>
            <p className="text-gray-700 leading-relaxed">
              We reserve the right to modify these Terms at any time. Continued use of the Service after changes constitutes acceptance of the modified Terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Account Registration</h2>
            <div className="space-y-3 text-gray-700">
              <p>To use the Service, you must:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Create an account with a valid email address and password</li>
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Be at least 13 years of age (or have parental consent)</li>
                <li>Notify us immediately of any unauthorized use of your account</li>
              </ul>
              <p className="mt-3">
                You are responsible for all activities that occur under your account.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Service Tiers</h2>

            <h3 className="text-xl font-semibold text-gray-900 mb-2">Free Tier</h3>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700 mb-4">
              <li>Unlimited streaming of Bible chapters and music</li>
              <li>Ad-supported (approximately 3 ads per hour)</li>
              <li>Standard audio quality (128kbps)</li>
              <li>No downloads or custom playlists</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-2">Premium Tier</h3>
            <ul className="list-disc list-inside space-y-2 ml-4 text-gray-700">
              <li>One-time payment of $9.99 for lifetime access</li>
              <li>Ad-free listening experience</li>
              <li>Premium audio quality (320kbps)</li>
              <li>Unlimited downloads for offline listening</li>
              <li>Custom playlist creation</li>
              <li>Early access to new content</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Payment and Refunds</h2>
            <div className="space-y-3 text-gray-700">
              <p>
                Premium subscriptions are processed securely through Stripe. All payments are in USD.
              </p>
              <p>
                <strong>Refund Policy:</strong> Due to the digital nature of our service and the lifetime access provided, all premium purchases are final and non-refundable. However, if you experience technical issues that prevent you from accessing the Service, please contact us at support@excellentmusic.com and we will work to resolve the issue.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Content Usage Rights</h2>
            <div className="space-y-3 text-gray-700">
              <p>
                All audio content, including Bible recordings and music, is provided for personal, non-commercial use only. You may not:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Copy, redistribute, or publicly perform the content</li>
                <li>Modify, reverse engineer, or create derivative works</li>
                <li>Remove copyright notices or attribution</li>
                <li>Use content for commercial purposes</li>
                <li>Share your premium account credentials with others</li>
                <li>Download content using unauthorized tools or methods</li>
              </ul>
              <p className="mt-3">
                Downloaded content (premium feature) is for offline personal listening only and remains subject to these Terms.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Intellectual Property</h2>
            <p className="text-gray-700 leading-relaxed">
              All content, features, and functionality of the Service, including but not limited to text, graphics, logos, audio recordings, and software, are owned by Excellent Music or its licensors and are protected by copyright, trademark, and other intellectual property laws. The Bible text itself is in the public domain, but our audio recordings are copyrighted works.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Prohibited Conduct</h2>
            <div className="space-y-3 text-gray-700">
              <p>You agree not to:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Violate any applicable laws or regulations</li>
                <li>Infringe on the rights of others</li>
                <li>Transmit harmful code, viruses, or malicious software</li>
                <li>Attempt to gain unauthorized access to the Service</li>
                <li>Interfere with or disrupt the Service or servers</li>
                <li>Use automated systems to access the Service</li>
                <li>Impersonate others or misrepresent your affiliation</li>
                <li>Harass, abuse, or harm other users</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Service Availability</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              We strive to provide reliable, uninterrupted access to the Service. However, we do not guarantee that the Service will always be available, error-free, or free from interruptions. We may modify, suspend, or discontinue any aspect of the Service at any time.
            </p>
            <p className="text-gray-700 leading-relaxed">
              We are not responsible for any loss or damage resulting from Service downtime, maintenance, or technical issues.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Third-Party Services</h2>
            <p className="text-gray-700 leading-relaxed">
              The Service may contain links to third-party websites or integrate with third-party services (such as payment processors). We are not responsible for the content, privacy practices, or terms of these third parties. Your use of third-party services is at your own risk.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Disclaimer of Warranties</h2>
            <p className="text-gray-700 leading-relaxed">
              THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. WE DO NOT WARRANT THAT THE SERVICE WILL BE UNINTERRUPTED, SECURE, OR ERROR-FREE.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Limitation of Liability</h2>
            <p className="text-gray-700 leading-relaxed">
              TO THE MAXIMUM EXTENT PERMITTED BY LAW, EXCELLENT MUSIC SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS OR REVENUES, WHETHER INCURRED DIRECTLY OR INDIRECTLY, OR ANY LOSS OF DATA, USE, GOODWILL, OR OTHER INTANGIBLE LOSSES RESULTING FROM YOUR USE OF THE SERVICE.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Indemnification</h2>
            <p className="text-gray-700 leading-relaxed">
              You agree to indemnify and hold harmless Excellent Music and its affiliates, officers, directors, employees, and agents from any claims, damages, losses, liabilities, and expenses (including legal fees) arising from your use of the Service or violation of these Terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">13. Termination</h2>
            <p className="text-gray-700 leading-relaxed mb-3">
              We reserve the right to suspend or terminate your account at any time, with or without notice, for violation of these Terms or for any other reason. You may also terminate your account at any time by contacting us.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Upon termination, your right to use the Service will immediately cease. Premium subscriptions are non-refundable upon termination.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">14. Governing Law</h2>
            <p className="text-gray-700 leading-relaxed">
              These Terms shall be governed by and construed in accordance with the laws of the United States, without regard to its conflict of law provisions. Any disputes arising from these Terms or the Service shall be resolved in the appropriate courts.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">15. Changes to Terms</h2>
            <p className="text-gray-700 leading-relaxed">
              We may update these Terms from time to time. We will notify you of significant changes by posting the new Terms on the Service and updating the "Last Updated" date. Your continued use of the Service after such changes constitutes acceptance of the updated Terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">16. Contact Information</h2>
            <p className="text-gray-700 leading-relaxed">
              If you have questions about these Terms, please contact us:
            </p>
            <div className="mt-3 text-gray-700">
              <p><strong>Email:</strong> support@excellentmusic.com</p>
              <p><strong>Website:</strong> www.thebibleinmusic.org</p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">17. Entire Agreement</h2>
            <p className="text-gray-700 leading-relaxed">
              These Terms, along with our Privacy Policy, constitute the entire agreement between you and Excellent Music regarding the Service and supersede all prior agreements and understandings.
            </p>
          </section>
        </div>

        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Copyright © 2024 Excellent Music. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}
